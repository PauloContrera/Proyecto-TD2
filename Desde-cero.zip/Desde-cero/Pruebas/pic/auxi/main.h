#include <18F2550.h>
#device ADC=10

#FUSES NOWDT                    //No Watch Dog Timer

#use delay(internal=4MHz)


/*
#include <main.h>

void main()
{

   while(TRUE)
   {


      //TODO: User Code
   }

}
*/
